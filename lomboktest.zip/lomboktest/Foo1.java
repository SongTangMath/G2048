import java.io.IOException;

public class Foo1 {

    public static void main(String[] args) throws IOException {
        Bean bean=new Bean();
        bean.name="zhangsan";
        System.out.println(bean.getName());
       
    }

}
@Data
class Bean{
   
    public String name;
    public Integer age;
}